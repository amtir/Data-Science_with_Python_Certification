print("Hello World")
print("Welcome to Edureka")


print("Happy Learning \nWelcome to Python")