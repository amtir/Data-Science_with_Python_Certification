X=10
Y=12

if(X<Y):
    print('X is less than Y')
elif(X>Y):
    print('X is greater than Y')
else:
    print('X and Y are equal')

# If else statement
a=30

if(a<10):
    print("Less than 10")
if(10<=a<=25):
    print("In between 10 and 25")
else:
    print("Greater than 25")

# if elif else

marks=70
if(marks<40):
    print("Fail")
elif(40<marks<=60):
    print("Average")
else:
    print("Congratulations!! Well done")
