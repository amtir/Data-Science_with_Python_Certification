A=[1,2,3.15,'edureka!']

print(A)