A=10
B='edureka!'

print(A,B)


#another example

x,y,z=10,20,30

print(x)
print(y)
print(z)