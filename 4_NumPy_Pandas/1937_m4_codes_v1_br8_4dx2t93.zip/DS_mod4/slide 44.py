import numpy as np
x=np.empty([3,2],dtype=int)
print(x)
