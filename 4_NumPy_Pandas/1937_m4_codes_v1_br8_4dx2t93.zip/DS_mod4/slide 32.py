import numpy as np

arr = np.zeros((5,5))
print(arr)