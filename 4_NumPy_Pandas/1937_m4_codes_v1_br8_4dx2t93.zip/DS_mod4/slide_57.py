import pandas, numpy

arr = numpy.array([10, 20, 30, 40, 50])
series = pandas.Series(arr)
print(series)