import numpy as np

list1 = [1, 2, 3, 4, 5]
arr = np.array(list1)
print(arr)

