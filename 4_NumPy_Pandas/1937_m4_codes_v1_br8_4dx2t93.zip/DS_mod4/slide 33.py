import numpy as np

vector = np.linspace(0, 20, 5)
print(vector)