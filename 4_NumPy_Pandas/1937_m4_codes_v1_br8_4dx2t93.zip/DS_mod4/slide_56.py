import pandas
series = pandas.Series()
print(series)